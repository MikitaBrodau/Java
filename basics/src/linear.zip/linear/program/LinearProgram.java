package linear.program;

public class LinearProgram {
    public static void main(String[] args) {
        Task1_1 task1_1 = new Task1_1();
        task1_1.Task1(10,10,10);

        Task1_2 task1_2 = new Task1_2();
        task1_2.Task2(4,5,6);

        Task1_3 task1_3 = new Task1_3();
        task1_3.Task3(1,1);

        Task1_4 task1_4 = new Task1_4();
        task1_4.Task4(532.156);

        Task1_5 task5 = new Task1_5();
        task5.Task5(24518);

        Task1_6 task1_6 = new Task1_6();
        task1_6.Task6(-2,3);
    }
}
