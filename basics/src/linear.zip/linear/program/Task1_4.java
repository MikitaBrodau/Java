package linear.program;

public class Task1_4 {
    public void Task4(double a){
        double y = (a * 1000) % 1000 + (int) a / 1000.0;
        System.out.println(y);
    }
}
