package linear.program;

public class Task1_6 {
    public void Task6 (double x, double y){
        System.out.println((y<=0 && y>-3) || (x >= -4 && x <= 4) || (x <= 2 && x >= -2) || (y >= 0 && y <= 4));
    }
}
