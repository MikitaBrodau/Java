package linear.program;

public class Task1_1 {
    public void Task1(int a, int b, int c){
        int z = ((a-3)*b/2) + c;
        System.out.println(z);
    }
}
