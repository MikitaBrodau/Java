package cycles;

import java.util.List;

public class Cycles {
    public static void main(String[] args) {
        Task3_1 task3_1 = new Task3_1();
        task3_1.Task3_1();

        Task3_2 task3_2 = new Task3_2();
        System.out.println(task3_2.Task3_2(1.2,6.2,0.6));

        Task3_3 task3_3 = new Task3_3();
        System.out.println(task3_3.Task3_3());

        Task3_4 task3_4 = new Task3_4();
        System.out.println(task3_4.Task3_4());

        Task3_5 task3_5 = new Task3_5();
        task3_5.Task3_5();

        Task3_6 task3_6 = new Task3_6();
        task3_6.Task3_6();

        Task3_7 task3_7 = new Task3_7();
        System.out.println(task3_7.Task3_7());
    }
}
