package cycles;

public class Task3_5 {
    public void Task3_5(){
        for (int i = 0; i < Character.MAX_VALUE; i++) {
            System.out.print((char)(i) + "  " + i);
        }
        System.out.println();
    }
}