package branching;

public class Task2_2 {
    public void Task2_2(int a, int b, int c, int d) {
        System.out.println(Math.max(Math.min(a,b),Math.min(c,d)));
    }
}