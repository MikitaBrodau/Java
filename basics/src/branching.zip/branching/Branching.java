package branching;

public class Branching {
    public static void main(String[] args) {
        Task2_1 task2_1 = new Task2_1();
        task2_1.Task2_1(90, 30);

        Task2_2 task2_2 = new Task2_2();
        task2_2.Task2_2(6, 2, 8734, 3);

        Task2_3 task2_3 = new Task2_3();
        task2_3.Task2_3(1, 3, 1, 23, 1, 2);

        Task2_4 task2_4 = new Task2_4();
        task2_4.Task2_4(220, 10, 50);

        Task2_5 task2_5 = new Task2_5();
        task2_5.Task2_5(2);
    }
}
